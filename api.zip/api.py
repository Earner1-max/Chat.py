from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
import requests
import base64

app = FastAPI(title="GTech AI")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

OLLAMA_BASE = "http://127.0.0.1:11434"
CHAT_MODEL  = "qwen3:0.6b"
VISION_MODEL = "minicpm-v:latest"

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#7c3aed">
<title>GTech AI</title>
<style>
  /* ─── Reset & Base ─── */
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:        #0d0a1a;
    --surface:   #12102a;
    --card:      #1a1635;
    --border:    rgba(139,92,246,.18);
    --border-hi: rgba(139,92,246,.45);
    --primary:   #7c3aed;
    --primary-h: #8b5cf6;
    --accent:    #a855f7;
    --emerald:   #10b981;
    --amber:     #f59e0b;
    --red:       #ef4444;
    --text:      #f1eeff;
    --text-muted:#8b80b0;
    --input-bg:  #0f0d22;
    --radius:    14px;
    --glow-v:    0 0 40px -12px rgba(139,92,246,.50);
    --glow-e:    0 0 40px -12px rgba(16,185,129,.45);
    --font: 'Inter', system-ui, -apple-system, sans-serif;
    --chat-max: 680px;
  }

  html, body { height: 100%; }
  body {
    font-family: var(--font);
    background: var(--bg);
    color: var(--text);
    display: flex;
    flex-direction: column;
    min-height: 100dvh;
    overflow-x: hidden;
  }

  /* scrollbar */
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border-hi); border-radius: 9px; }

  /* ─── Shell ─── */
  .shell {
    display: flex;
    flex-direction: column;
    height: 100dvh;
    max-width: var(--chat-max);
    margin: 0 auto;
    width: 100%;
  }

  /* ─── Header ─── */
  header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 20px;
    border-bottom: 1px solid var(--border);
    background: rgba(13,10,26,.85);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    position: sticky;
    top: 0;
    z-index: 40;
  }
  .logo-circle {
    width: 38px; height: 38px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary), var(--accent));
    display: grid; place-items: center;
    box-shadow: var(--glow-v);
    flex-shrink: 0;
  }
  .logo-circle svg { width: 20px; height: 20px; color: #fff; }
  .header-info { flex: 1; min-width: 0; }
  .header-name { font-size: .93rem; font-weight: 800; letter-spacing: -.01em; }
  .header-sub  { font-size: .72rem; color: var(--text-muted); display: flex; align-items: center; gap: 5px; margin-top: 1px; }
  .dot-online  { width: 6px; height: 6px; border-radius: 50%; background: var(--emerald); box-shadow: 0 0 6px var(--emerald); }
  .model-badge {
    font-size: .68rem; font-weight: 700;
    padding: 3px 10px;
    border-radius: 20px;
    background: rgba(139,92,246,.15);
    border: 1px solid var(--border);
    color: var(--accent);
    white-space: nowrap;
  }

  /* ─── Tabs ─── */
  .tabs {
    display: flex;
    gap: 4px;
    padding: 10px 16px;
    background: var(--surface);
    border-bottom: 1px solid var(--border);
  }
  .tab-btn {
    flex: 1;
    display: flex; align-items: center; justify-content: center; gap: 7px;
    padding: 9px 0;
    border-radius: 10px;
    border: 1px solid transparent;
    background: transparent;
    color: var(--text-muted);
    font-size: .82rem; font-weight: 600;
    cursor: pointer;
    transition: all .18s;
  }
  .tab-btn svg { width: 15px; height: 15px; }
  .tab-btn.active {
    background: rgba(124,58,237,.18);
    border-color: var(--border-hi);
    color: var(--primary-h);
    box-shadow: var(--glow-v);
  }
  .tab-btn:hover:not(.active) {
    background: rgba(255,255,255,.04);
    color: var(--text);
  }

  /* ─── Panels ─── */
  .panel { display: none; flex-direction: column; flex: 1; min-height: 0; }
  .panel.visible { display: flex; }

  /* ─── Chat Messages ─── */
  .messages {
    flex: 1;
    overflow-y: auto;
    padding: 20px 16px;
    display: flex;
    flex-direction: column;
    gap: 14px;
    scroll-behavior: smooth;
  }

  .msg {
    display: flex;
    gap: 9px;
    max-width: 88%;
    animation: fadeUp .22s ease-out;
  }
  .msg.user { align-self: flex-end; flex-direction: row-reverse; }
  .msg.ai   { align-self: flex-start; }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(8px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  .avatar {
    width: 30px; height: 30px;
    border-radius: 50%;
    flex-shrink: 0;
    display: grid; place-items: center;
    font-size: .75rem; font-weight: 800;
    margin-top: 2px;
  }
  .avatar.ai {
    background: linear-gradient(135deg, var(--primary), var(--accent));
    box-shadow: 0 0 12px rgba(139,92,246,.4);
  }
  .avatar.ai svg { width: 14px; height: 14px; color: #fff; }
  .avatar.user {
    background: rgba(139,92,246,.22);
    border: 1px solid var(--border-hi);
    color: var(--accent);
  }
  .avatar.user svg { width: 14px; height: 14px; }

  .bubble {
    padding: 11px 15px;
    border-radius: 16px;
    font-size: .875rem;
    line-height: 1.6;
    max-width: 100%;
    word-break: break-word;
    white-space: pre-wrap;
  }
  .msg.ai .bubble {
    background: var(--card);
    border: 1px solid var(--border);
    border-bottom-left-radius: 4px;
    color: var(--text);
  }
  .msg.user .bubble {
    background: linear-gradient(135deg, var(--primary), var(--accent));
    color: #fff;
    border-bottom-right-radius: 4px;
    box-shadow: 0 4px 20px rgba(124,58,237,.35);
  }
  .bubble img {
    max-width: 220px;
    border-radius: 10px;
    margin-bottom: 8px;
    display: block;
  }

  /* typing dots */
  .typing-dots { display: flex; gap: 4px; padding: 4px 2px; }
  .typing-dots span {
    width: 7px; height: 7px;
    border-radius: 50%;
    background: var(--primary-h);
    animation: bounce 1.1s infinite ease-in-out;
  }
  .typing-dots span:nth-child(2) { animation-delay: .16s; }
  .typing-dots span:nth-child(3) { animation-delay: .32s; }
  @keyframes bounce {
    0%,80%,100% { transform: translateY(0); opacity: .6; }
    40%          { transform: translateY(-6px); opacity: 1; }
  }

  /* ─── Input bar ─── */
  .input-bar {
    padding: 12px 14px;
    border-top: 1px solid var(--border);
    background: rgba(13,10,26,.9);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
  }
  .compose {
    display: flex;
    align-items: flex-end;
    gap: 8px;
    background: var(--input-bg);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 8px 8px 8px 14px;
    transition: border-color .18s, box-shadow .18s;
  }
  .compose:focus-within {
    border-color: var(--border-hi);
    box-shadow: 0 0 0 3px rgba(139,92,246,.12);
  }
  .compose textarea {
    flex: 1;
    background: transparent;
    border: none;
    outline: none;
    resize: none;
    font-family: var(--font);
    font-size: .88rem;
    line-height: 1.55;
    color: var(--text);
    max-height: 120px;
    min-height: 22px;
    padding: 2px 0;
  }
  .compose textarea::placeholder { color: var(--text-muted); }
  .icon-btn {
    width: 36px; height: 36px;
    border-radius: 10px;
    border: none;
    background: transparent;
    color: var(--text-muted);
    cursor: pointer;
    display: grid; place-items: center;
    transition: background .15s, color .15s;
    flex-shrink: 0;
  }
  .icon-btn:hover { background: rgba(255,255,255,.07); color: var(--text); }
  .icon-btn svg { width: 18px; height: 18px; }
  .send-btn {
    width: 36px; height: 36px;
    border-radius: 10px;
    border: none;
    background: linear-gradient(135deg, var(--primary), var(--accent));
    color: #fff;
    cursor: pointer;
    display: grid; place-items: center;
    transition: opacity .15s, transform .1s, box-shadow .15s;
    flex-shrink: 0;
    box-shadow: 0 2px 12px rgba(124,58,237,.4);
  }
  .send-btn:hover { opacity: .88; box-shadow: 0 4px 18px rgba(124,58,237,.55); }
  .send-btn:active { transform: scale(.95); }
  .send-btn:disabled { opacity: .35; cursor: not-allowed; }
  .send-btn svg { width: 17px; height: 17px; }

  /* pending photo preview in compose */
  .pending-photo-wrap {
    padding: 6px 14px 0;
    display: flex; align-items: center; gap: 10px;
  }
  .pending-photo-wrap img {
    width: 52px; height: 52px;
    border-radius: 8px;
    object-fit: cover;
    border: 1px solid var(--border-hi);
  }
  .pending-photo-wrap .remove-photo {
    width: 20px; height: 20px;
    border-radius: 50%;
    background: var(--red);
    border: none; cursor: pointer;
    color: #fff; font-size: .7rem; font-weight: 900;
    display: grid; place-items: center;
    line-height: 1;
  }
  .pending-photo-wrap .photo-label {
    font-size: .72rem; color: var(--text-muted); flex: 1;
  }

  /* ─── Vision Panel ─── */
  .vision-panel {
    flex: 1; overflow-y: auto;
    padding: 24px 16px;
    display: flex; flex-direction: column; gap: 20px;
  }

  .drop-zone {
    border: 2px dashed var(--border-hi);
    border-radius: var(--radius);
    padding: 40px 24px;
    text-align: center;
    background: rgba(124,58,237,.05);
    cursor: pointer;
    transition: background .18s, border-color .18s;
    position: relative;
  }
  .drop-zone:hover, .drop-zone.drag-over {
    background: rgba(124,58,237,.12);
    border-color: var(--primary-h);
  }
  .drop-zone input[type=file] {
    position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%;
  }
  .drop-zone-icon {
    width: 52px; height: 52px;
    border-radius: 50%;
    background: rgba(124,58,237,.15);
    display: grid; place-items: center;
    margin: 0 auto 14px;
  }
  .drop-zone-icon svg { width: 26px; height: 26px; color: var(--primary-h); }
  .drop-zone h3 { font-size: .95rem; font-weight: 700; margin-bottom: 5px; }
  .drop-zone p { font-size: .78rem; color: var(--text-muted); }

  .vision-preview-wrap {
    border-radius: var(--radius);
    border: 1px solid var(--border);
    background: var(--card);
    overflow: hidden;
    box-shadow: var(--glow-v);
  }
  .vision-preview-wrap img {
    width: 100%; max-height: 320px;
    object-fit: cover; display: block;
  }
  .vision-preview-info {
    padding: 12px 16px;
    display: flex; align-items: center; justify-content: space-between;
    gap: 12px;
  }
  .vision-preview-info span { font-size: .78rem; color: var(--text-muted); }
  .clear-btn {
    padding: 5px 14px;
    border-radius: 8px;
    border: 1px solid var(--border);
    background: transparent;
    color: var(--text-muted);
    font-size: .75rem; font-weight: 600; cursor: pointer;
    transition: all .15s;
  }
  .clear-btn:hover { background: rgba(239,68,68,.1); border-color: var(--red); color: var(--red); }

  .analyze-btn {
    padding: 13px 24px;
    border-radius: 12px;
    border: none;
    background: linear-gradient(135deg, var(--primary), var(--accent));
    color: #fff;
    font-size: .88rem; font-weight: 700;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center; gap: 9px;
    box-shadow: 0 4px 20px rgba(124,58,237,.4);
    transition: opacity .15s, transform .1s, box-shadow .15s;
  }
  .analyze-btn:hover { opacity: .88; box-shadow: 0 6px 24px rgba(124,58,237,.55); }
  .analyze-btn:active { transform: scale(.98); }
  .analyze-btn:disabled { opacity: .35; cursor: not-allowed; }
  .analyze-btn svg { width: 18px; height: 18px; }

  .vision-result {
    border-radius: var(--radius);
    border: 1px solid rgba(16,185,129,.35);
    background: rgba(16,185,129,.05);
    box-shadow: var(--glow-e);
    padding: 18px;
    font-size: .875rem;
    line-height: 1.65;
    white-space: pre-wrap;
    word-break: break-word;
    color: var(--text);
    animation: fadeUp .25s ease-out;
  }
  .vision-result-header {
    display: flex; align-items: center; gap: 8px;
    margin-bottom: 12px;
    font-size: .78rem; font-weight: 700;
    color: var(--emerald);
  }
  .vision-result-header svg { width: 15px; height: 15px; }

  /* status row */
  .status-row {
    display: flex; align-items: center; gap: 8px;
    font-size: .78rem; font-weight: 600;
    padding: 0 2px;
    min-height: 20px;
    color: var(--text-muted);
    transition: color .2s;
  }
  .status-row.error { color: var(--red); }
  .status-row.ok    { color: var(--emerald); }
  .status-row.busy  { color: var(--accent); }
  .status-row svg   { width: 14px; height: 14px; flex-shrink: 0; }

  /* spinner */
  .spinner {
    width: 14px; height: 14px;
    border: 2px solid rgba(168,85,247,.3);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin .7s linear infinite;
    flex-shrink: 0;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  /* empty state */
  .empty-state {
    flex: 1;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    gap: 10px;
    color: var(--text-muted);
    font-size: .82rem;
    text-align: center;
    padding: 32px 24px;
  }
  .empty-state svg { width: 44px; height: 44px; opacity: .35; }
  .empty-state p { max-width: 240px; }

  /* char hint */
  .char-hint { font-size: .68rem; color: var(--text-muted); text-align: right; padding: 4px 2px 0; }

  /* ─── Responsive ─── */
  @media (max-width: 480px) {
    header { padding: 12px 14px; }
    .messages { padding: 14px 10px; }
    .input-bar { padding: 10px 10px; }
    .vision-panel { padding: 16px 10px; }
  }
</style>
</head>
<body>
<div class="shell">

  <!-- Header -->
  <header>
    <div class="logo-circle">
      <!-- Brain icon -->
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"/>
        <path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.46 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2Z"/>
      </svg>
    </div>
    <div class="header-info">
      <div class="header-name">GTech AI</div>
      <div class="header-sub">
        <span class="dot-online"></span>
        <span>Online · Powered by Ollama</span>
      </div>
    </div>
    <div class="model-badge" id="modelBadge">qwen3:0.6b</div>
  </header>

  <!-- Tabs -->
  <div class="tabs">
    <button class="tab-btn active" id="tabChat" onclick="switchTab('chat')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
      Chat
    </button>
    <button class="tab-btn" id="tabVision" onclick="switchTab('vision')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
        <polyline points="21 15 16 10 5 21"/>
      </svg>
      Vision
    </button>
  </div>

  <!-- CHAT PANEL -->
  <div class="panel visible" id="panelChat">
    <div class="messages" id="messages">
      <div class="empty-state" id="emptyState">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
        <p>Ask me anything — crypto, markets, analysis, or general questions.</p>
      </div>
    </div>

    <div class="input-bar">
      <div id="pendingPhotoWrap" style="display:none" class="pending-photo-wrap">
        <img id="pendingPhotoPreview" src="" alt="">
        <span class="photo-label" id="pendingPhotoName"></span>
        <button class="remove-photo" onclick="clearChatPhoto()">&#x2715;</button>
      </div>

      <div class="compose">
        <textarea
          id="chatInput"
          rows="1"
          placeholder="Type a message…"
          oninput="autoResize(this)"
          onkeydown="handleKey(event)"
        ></textarea>

        <label class="icon-btn" title="Attach image">
          <input type="file" id="chatPhotoInput" accept="image/*" style="display:none" onchange="attachChatPhoto(event)">
          <!-- Paperclip -->
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/>
          </svg>
        </label>

        <button class="send-btn" id="sendBtn" onclick="sendChat()" title="Send">
          <!-- Send arrow -->
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
          </svg>
        </button>
      </div>

      <div class="status-row" id="chatStatus"></div>
    </div>
  </div>

  <!-- VISION PANEL -->
  <div class="panel" id="panelVision">
    <div class="vision-panel">

      <div id="dropZone" class="drop-zone" ondragover="onDragOver(event)" ondragleave="onDragLeave(event)" ondrop="onDrop(event)">
        <input type="file" accept="image/*" id="visionFileInput" onchange="onVisionFile(event)">
        <div class="drop-zone-icon">
          <!-- Upload icon -->
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
          </svg>
        </div>
        <h3>Drop an image here</h3>
        <p>or click to browse — JPG, PNG, WebP, GIF</p>
      </div>

      <div id="visionPreviewWrap" class="vision-preview-wrap" style="display:none">
        <img id="visionPreviewImg" src="" alt="Preview">
        <div class="vision-preview-info">
          <span id="visionFileName">image.jpg</span>
          <button class="clear-btn" onclick="clearVision()">Remove</button>
        </div>
      </div>

      <button class="analyze-btn" id="analyzeBtn" onclick="analyzeVision()" style="display:none" disabled>
        <!-- Eye icon -->
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
          <circle cx="12" cy="12" r="3"/>
        </svg>
        Analyze Image
      </button>

      <div class="status-row" id="visionStatus"></div>

      <div id="visionResultWrap" style="display:none" class="vision-result">
        <div class="vision-result-header">
          <!-- Sparkle/star icon -->
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
          </svg>
          Vision Analysis
        </div>
        <div id="visionResultText"></div>
      </div>

    </div>
  </div>

</div><!-- .shell -->

<script>
  /* ─── State ─── */
  let chatPhotoFile = null;
  let chatPhotoDataUrl = null;
  let visionFile = null;
  let visionBusy = false;
  let chatBusy  = false;

  /* ─── Tab switching ─── */
  function switchTab(tab) {
    document.getElementById('tabChat').classList.toggle('active', tab === 'chat');
    document.getElementById('tabVision').classList.toggle('active', tab === 'vision');
    document.getElementById('panelChat').classList.toggle('visible', tab === 'chat');
    document.getElementById('panelVision').classList.toggle('visible', tab === 'vision');
  }

  /* ─── Auto-resize textarea ─── */
  function autoResize(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  }

  /* ─── Enter to send (Shift+Enter = newline) ─── */
  function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendChat();
    }
  }

  /* ─── Chat photo attach ─── */
  function attachChatPhoto(e) {
    const file = e.target.files[0];
    if (!file) return;
    chatPhotoFile = file;
    const reader = new FileReader();
    reader.onload = () => {
      chatPhotoDataUrl = reader.result;
      document.getElementById('pendingPhotoPreview').src = chatPhotoDataUrl;
      document.getElementById('pendingPhotoName').textContent = file.name;
      document.getElementById('pendingPhotoWrap').style.display = 'flex';
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  }

  function clearChatPhoto() {
    chatPhotoFile = null;
    chatPhotoDataUrl = null;
    document.getElementById('pendingPhotoWrap').style.display = 'none';
    document.getElementById('pendingPhotoPreview').src = '';
  }

  /* ─── Chat send ─── */
  async function sendChat() {
    if (chatBusy) return;
    const input = document.getElementById('chatInput');
    const text  = input.value.trim();
    if (!text && !chatPhotoFile) return;

    chatBusy = true;
    document.getElementById('sendBtn').disabled = true;
    setStatus('chatStatus', 'busy', null, 'Sending…');

    // hide empty state
    document.getElementById('emptyState').style.display = 'none';

    // render user message
    const photoDataUrl = chatPhotoDataUrl;
    const photoFile    = chatPhotoFile;
    appendMsg('user', text, photoDataUrl);
    input.value = '';
    input.style.height = 'auto';
    clearChatPhoto();

    // show typing
    const typingId = appendTyping();
    scrollToBottom();

    try {
      let reply;
      if (photoFile) {
        // send to /vision
        document.getElementById('modelBadge').textContent = 'minicpm-v';
        setStatus('chatStatus', 'busy', null, 'Analyzing image…');
        const fd = new FormData();
        fd.append('file', photoFile);
        if (text) fd.append('prompt', text);
        const r = await fetch('/vision', { method: 'POST', body: fd });
        if (!r.ok) throw new Error('Server error ' + r.status);
        const d = await r.json();
        reply = d.reply;
        document.getElementById('modelBadge').textContent = 'minicpm-v';
      } else {
        document.getElementById('modelBadge').textContent = 'qwen3:0.6b';
        setStatus('chatStatus', 'busy', null, 'Thinking…');
        const r = await fetch('/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: text })
        });
        if (!r.ok) throw new Error('Server error ' + r.status);
        const d = await r.json();
        reply = d.reply;
      }
      removeEl(typingId);
      appendMsg('ai', reply);
      setStatus('chatStatus', 'ok', iconCheck(), 'Reply ready');
    } catch (err) {
      removeEl(typingId);
      appendMsg('ai', 'Something went wrong: ' + err.message);
      setStatus('chatStatus', 'error', iconX(), 'Failed');
    }

    chatBusy = false;
    document.getElementById('sendBtn').disabled = false;
    scrollToBottom();
  }

  /* ─── Vision panel ─── */
  function onDragOver(e) {
    e.preventDefault();
    document.getElementById('dropZone').classList.add('drag-over');
  }
  function onDragLeave() {
    document.getElementById('dropZone').classList.remove('drag-over');
  }
  function onDrop(e) {
    e.preventDefault();
    document.getElementById('dropZone').classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) loadVisionFile(file);
  }
  function onVisionFile(e) {
    const file = e.target.files[0];
    if (file) loadVisionFile(file);
    e.target.value = '';
  }
  function loadVisionFile(file) {
    visionFile = file;
    const url  = URL.createObjectURL(file);
    document.getElementById('visionPreviewImg').src = url;
    document.getElementById('visionFileName').textContent = file.name + ' · ' + (file.size / 1024).toFixed(0) + ' KB';
    document.getElementById('visionPreviewWrap').style.display = 'block';
    document.getElementById('analyzeBtn').style.display   = 'flex';
    document.getElementById('analyzeBtn').disabled        = false;
    document.getElementById('visionResultWrap').style.display = 'none';
    setStatus('visionStatus', '', null, '');
  }
  function clearVision() {
    visionFile = null;
    document.getElementById('visionPreviewWrap').style.display = 'none';
    document.getElementById('analyzeBtn').style.display        = 'none';
    document.getElementById('visionResultWrap').style.display  = 'none';
    setStatus('visionStatus', '', null, '');
  }
  async function analyzeVision() {
    if (!visionFile || visionBusy) return;
    visionBusy = true;
    document.getElementById('analyzeBtn').disabled = true;
    setStatus('visionStatus', 'busy', null, 'Analyzing image…');

    try {
      const fd = new FormData();
      fd.append('file', visionFile);
      const r = await fetch('/vision', { method: 'POST', body: fd });
      if (!r.ok) throw new Error('Server error ' + r.status);
      const d = await r.json();
      document.getElementById('visionResultText').textContent = d.reply;
      document.getElementById('visionResultWrap').style.display = 'block';
      setStatus('visionStatus', 'ok', iconCheck(), 'Analysis complete');
    } catch (err) {
      setStatus('visionStatus', 'error', iconX(), 'Failed: ' + err.message);
    }

    visionBusy = false;
    document.getElementById('analyzeBtn').disabled = false;
  }

  /* ─── DOM helpers ─── */
  function appendMsg(role, text, photoUrl) {
    const msgs = document.getElementById('messages');
    const id   = 'msg-' + Date.now() + '-' + Math.random().toString(36).slice(2);

    const isAi   = role === 'ai';
    const avatarSvg = isAi
      ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.46 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2Z"/></svg>`
      : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`;

    let bubbleInner = '';
    if (photoUrl) bubbleInner += `<img src="${photoUrl}" alt="attachment">`;
    if (text)     bubbleInner += escHtml(text);

    const div = document.createElement('div');
    div.id  = id;
    div.className = 'msg ' + role;
    div.innerHTML = `
      <div class="avatar ${role}">${avatarSvg}</div>
      <div class="bubble">${bubbleInner}</div>`;
    msgs.appendChild(div);
    return id;
  }

  function appendTyping() {
    const msgs = document.getElementById('messages');
    const id   = 'typing-' + Date.now();
    const div  = document.createElement('div');
    div.id    = id;
    div.className = 'msg ai';
    div.innerHTML = `
      <div class="avatar ai"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.46 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2Z"/></svg></div>
      <div class="bubble">
        <div class="typing-dots"><span></span><span></span><span></span></div>
      </div>`;
    msgs.appendChild(div);
    scrollToBottom();
    return id;
  }

  function removeEl(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
  }

  function scrollToBottom() {
    const msgs = document.getElementById('messages');
    setTimeout(() => { msgs.scrollTop = msgs.scrollHeight; }, 30);
  }

  function escHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
  }

  function setStatus(id, cls, iconHtml, text) {
    const el = document.getElementById(id);
    el.className = 'status-row' + (cls ? ' ' + cls : '');
    if (cls === 'busy') {
      el.innerHTML = `<div class="spinner"></div><span>${text}</span>`;
    } else if (iconHtml) {
      el.innerHTML = iconHtml + `<span>${text}</span>`;
    } else {
      el.innerHTML = text ? `<span>${text}</span>` : '';
    }
  }

  function iconCheck() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
  }
  function iconX() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
  }
</script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
def home():
    return HTML


@app.post("/chat")
async def chat(data: dict):
    message = data.get("message", "").strip()
    if not message:
        raise HTTPException(status_code=400, detail="message is required")
    try:
        r = requests.post(
            f"{OLLAMA_BASE}/api/generate",
            json={
                "model": CHAT_MODEL,
                "prompt": message,
                "stream": False,
            },
            timeout=120,
        )
        r.raise_for_status()
        return {"reply": r.json().get("response", "")}
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Ollama is not reachable. Make sure it is running.")
    except requests.exceptions.Timeout:
        raise HTTPException(status_code=504, detail="Ollama timed out.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/vision")
async def vision(file: UploadFile = File(...), prompt: str = "Describe this image in detail"):
    image_bytes = await file.read()
    image_b64   = base64.b64encode(image_bytes).decode()
    try:
        r = requests.post(
            f"{OLLAMA_BASE}/api/generate",
            json={
                "model": VISION_MODEL,
                "prompt": prompt or "Describe this image in detail",
                "images": [image_b64],
                "stream": False,
            },
            timeout=300,
        )
        r.raise_for_status()
        return {"reply": r.json().get("response", "")}
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Ollama is not reachable.")
    except requests.exceptions.Timeout:
        raise HTTPException(status_code=504, detail="Vision model timed out.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5004)
